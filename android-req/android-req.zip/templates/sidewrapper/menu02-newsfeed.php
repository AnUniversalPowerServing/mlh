<div class="list-group">
  <div class="list-group-item bg-grey" data-target="#sideWrapper-menu2-req" data-toggle="collapse">
	<b>MENU#2: NewsFeed</b><i class="fa fa-angle-down pull-right" aria-hidden="true"></i>
  </div>
  <div id="sideWrapper-menu2-req" class="collapse">
	<div class="list-group-item">
	  	 
	</div><!-- list-group-item -->
  </div><!-- collapse -->
</div>